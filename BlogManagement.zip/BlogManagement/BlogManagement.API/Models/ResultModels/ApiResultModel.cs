﻿using System;
namespace BlogManagement.API.Models.ResultModels
{
    public class ApiResultModel
    {
        public string VersionName { get; set; }
        public string VersionDetail { get; set; }
    }
}
