﻿using System;
namespace BlogManagement.API.Models.PostModels
{
    public class BasePostModel
    {

        public int Id { get; set; }
    }
}
