﻿using System;
namespace BlogManagement.API.Models
{
    public class AppSettings
    {
        public string SecretKey { get; set; }
    }
}
